document.addEventListener("DOMContentLoaded", () => {
    const toggleBtn = document.getElementById("darkToggle");

    // Apply saved theme on every page
    if (localStorage.getItem("theme") === "dark") {
        document.body.classList.add("dark");
        if (toggleBtn) toggleBtn.innerText = "Light Mode ☀️";
    }

    // Button click
    if (toggleBtn) {
        toggleBtn.addEventListener("click", () => {
            document.body.classList.toggle("dark");

            if (document.body.classList.contains("dark")) {
                localStorage.setItem("theme", "dark");
                toggleBtn.innerText = "Light Mode ☀️";
            } else {
                localStorage.setItem("theme", "light");
                toggleBtn.innerText = "Dark Mode 🌙";
            }
        });
    }
});
